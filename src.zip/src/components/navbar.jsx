import { Link, useNavigate } from "react-router-dom";
import { FaHeart, FaShoppingCart } from "react-icons/fa";

export default function Navbar({ user, setUser, cartItems, favorites }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  };

  const totalCartCount =
    cartItems?.reduce((sum, i) => sum + i.quantity, 0) || 0;

  return (
    <nav className="bg-[#6a4f4b] text-white font-bold py-4 px-8 shadow-lg">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-2xl md:text-3xl tracking-wide">
          <Link to="/">GJ Cafe</Link>
        </h1>

        <ul className="flex space-x-6 md:space-x-8 text-lg items-center">
          <li>
            <Link to="/" className="hover:text-yellow-500">
              Home
            </Link>
          </li>

          <li>
            <Link to="/menu" className="hover:text-yellow-500">
              Menu
            </Link>
          </li>

          <li>
            <Link to="/about" className="hover:text-yellow-500">
              About Us
            </Link>
          </li>

          {/* Show My Orders only if logged in */}
          {user && (
            <li>
              <Link to="/orders" className="hover:text-yellow-500">
                My Orders
              </Link>
            </li>
          )}

          <li>
            <Link
              to="/favorites"
              className="flex items-center gap-1 text-red-500 hover:text-red-600"
            >
              Favorites <FaHeart /> ({favorites?.length || 0})
            </Link>
          </li>

          <li>
            <Link
              to="/cart"
              className="flex items-center gap-1 text-yellow-400 hover:text-yellow-500"
            >
              Cart <FaShoppingCart /> ({totalCartCount})
            </Link>
          </li>

          {!user ? (
            <li>
              <Link to="/login" className="hover:text-yellow-500">
                Login
              </Link>
            </li>
          ) : (
            <>
              <li className="text-yellow-400">
                Hi, {user.name}
              </li>

              <li>
                <button
                  onClick={handleLogout}
                  className="hover:text-yellow-500"
                >
                  Logout
                </button>
              </li>
              {user?.role === "admin" && (
                <li>
                  <Link to="/admin" className="hover:text-yellow-500">
                    Admin
                  </Link>
                </li>
              )}

            </>
          )}
        </ul>
      </div>
    </nav>
  );
}
