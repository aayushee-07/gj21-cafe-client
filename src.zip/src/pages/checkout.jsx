import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../lib/apiClient";

export default function Checkout({ cartItems, clearCart }) {
  const navigate = useNavigate();

  const [address, setAddress] = useState({
    fullName: "",
    phone: "",
    house: "",
    street: "",
    area: "",
    city: "",
    pincode: "",
    landmark: "",
    deliveryDistance: "",
  });

  const [paymentMethod, setPaymentMethod] = useState("COD");
  const [instructions, setInstructions] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // ✅ Coupon States
  const [availableCoupons, setAvailableCoupons] = useState([]);
  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [couponMessage, setCouponMessage] = useState("");

  /* ===============================
     FETCH ACTIVE COUPONS
  =============================== */
  useEffect(() => {
    api.get("/coupons/active")
      .then(res => setAvailableCoupons(res.data))
      .catch(err => console.error(err));
  }, []);

  /* ===============================
     PRICING CALCULATION
  =============================== */
  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  const numericDistance = Number(address.deliveryDistance);

  const deliveryFee =
    numericDistance <= 5
      ? 20
      : numericDistance <= 10
        ? 40
        : 0;

  const total = subtotal + deliveryFee;
  const finalTotal = total - discount;

  /* ===============================
     APPLY COUPON
  =============================== */
  const applyCoupon = async (code) => {
    try {
      const res = await api.post("/coupons/validate", {
        code,
        orderAmount: total,
      });

      setCouponCode(code);
      setDiscount(res.data.discount);
      setCouponMessage("Coupon applied successfully 🎉");
    } catch (err) {
      setDiscount(0);
      setCouponMessage(
        err.response?.data?.message || "Invalid coupon"
      );
    }
  };

  /* ===============================
     HANDLE INPUT
  =============================== */
  const handleChange = (e) => {
    const { name, value } = e.target;

    setAddress({
      ...address,
      [name]: name === "deliveryDistance" ? Number(value) : value,
    });
  };

  /* ===============================
     PLACE ORDER
  =============================== */
  const handlePlaceOrder = async () => {
    setError("");

    // ✅ Only required fields
    const requiredFields = [
      "fullName",
      "phone",
      "house",
      "city",
      "pincode",
      "deliveryDistance",
    ];

    for (let field of requiredFields) {
      if (!address[field] || address[field].toString().trim() === "") {
        setError("⚠️ Please fill required details");
        return;
      }
    }

    if (address.phone.length !== 10) {
      setError("⚠️ Enter valid 10 digit phone number");
      return;
    }

    if (Number(address.deliveryDistance) > 10) {
      setError("⚠️ Delivery available only within 10 KM");
      return;
    }

    setLoading(true);

    try {
      const orderItems = cartItems.map((item) => ({
        menuItem: item._id,
        quantity: item.quantity,
      }));

      // 1️⃣ Create order FIRST
      const res = await api.post("/orders", {
        items: orderItems,
        deliveryAddress: address,
        paymentMethod,
        specialInstructions: instructions,
        couponCode,
      });

      const orderId = res.data.order._id;

      // 2️⃣ If ONLINE payment → Stripe
      if (paymentMethod === "ONLINE") {

        const stripeRes = await api.post("/payment/create-checkout-session", {
          items: cartItems,
          orderId,
        });

        window.location.href = stripeRes.data.url;
        return;
      }

      // 3️⃣ COD Order
      clearCart();
      localStorage.removeItem("cart");
      navigate(`/order-success/${orderId}`);

    } catch (err) {
      setError(err.response?.data?.error || "Order failed ❌");
    } finally {
      setLoading(false);
    }
  };

  if (!cartItems.length) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <p>Your cart is empty.</p>
      </div>
    );
  }

  return (
    <main className="bg-gray-50 min-h-screen py-8">
      <div className="container mx-auto px-6 max-w-6xl">
        <h1 className="text-3xl font-bold mb-6 text-center">
          Checkout
        </h1>

        <div className="grid md:grid-cols-2 gap-8">

          {/* ================= DELIVERY SECTION ================= */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold mb-4">
              Delivery Address
            </h2>

            {[
              ["fullName", "Full Name *"],
              ["phone", "Phone Number *"],
              ["house", "House / Flat No *"],
              ["street", "Street (Optional)"],
              ["area", "Area (Optional)"],
              ["city", "City *"],
              ["pincode", "Pincode *"],
              ["deliveryDistance", "Delivery Distance (KM) *"],
              ["landmark", "Landmark (Optional)"],
            ].map(([name, label]) => (
              <div className="mb-4" key={name}>
                <label className="block mb-1 font-medium">
                  {label}
                </label>
                <input
                  type={name === "deliveryDistance" ? "number" : "text"}
                  name={name}
                  value={address[name]}
                  onChange={handleChange}
                  className="w-full border p-3 rounded-lg"
                />
              </div>
            ))}

            <div className="mb-4">
              <label className="block mb-1 font-medium">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full border p-3 rounded-lg"
              >
                <option value="COD">Cash on Delivery</option>
                <option value="ONLINE">Online Payment</option>
              </select>
            </div>

            <textarea
              placeholder="Special Instructions (Optional)"
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full border p-3 rounded-lg"
            />

            {error && (
              <p className="text-red-600 mt-3 font-medium">
                {error}
              </p>
            )}
          </div>

          {/* ================= ORDER SUMMARY ================= */}
          <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-xl font-semibold mb-4">
              Order Summary
            </h2>

            {cartItems.map((item) => (
              <div key={item._id} className="flex justify-between mb-2">
                <span>{item.name} × {item.quantity}</span>
                <span>₹{item.price * item.quantity}</span>
              </div>
            ))}

            <hr className="my-3" />

            <div className="flex justify-between">
              <span>Subtotal</span>
              <span>₹{subtotal}</span>
            </div>

            <div className="flex justify-between">
              <span>Delivery Fee</span>
              <span>₹{deliveryFee}</span>
            </div>

            {/* 🎁 AVAILABLE COUPONS */}
            <div className="bg-yellow-50 p-3 rounded-lg mt-4">
              <h3 className="font-semibold mb-2">
                🎁 Available Coupons
              </h3>

              {availableCoupons.length === 0 && (
                <p className="text-gray-500 text-sm">
                  No active coupons
                </p>
              )}

              {availableCoupons.map((coupon) => (
                <div
                  key={coupon._id}
                  className="flex justify-between items-center border-b py-2"
                >
                  <div>
                    <p className="font-bold">{coupon.code}</p>
                    <p className="text-sm text-gray-600">
                      {coupon.discountType === "percentage"
                        ? `${coupon.discountValue}% off`
                        : `₹${coupon.discountValue} off`}
                      {" "} (Min ₹{coupon.minOrderAmount})
                    </p>
                  </div>

                  <button
                    onClick={() => applyCoupon(coupon.code)}
                    className="bg-green-600 text-white px-3 py-1 rounded"
                  >
                    Apply
                  </button>
                </div>
              ))}
            </div>

            {couponMessage && (
              <p className="text-sm text-green-600 mt-2">
                {couponMessage}
              </p>
            )}

            {discount > 0 && (
              <div className="flex justify-between mt-3 text-green-600">
                <span>Discount ({couponCode})</span>
                <span>-₹{discount}</span>
              </div>
            )}

            <hr className="my-3" />

            <div className="flex justify-between font-bold text-lg">
              <span>Total</span>
              <span>₹{finalTotal}</span>
            </div>

            <button
              onClick={handlePlaceOrder}
              disabled={loading}
              className="w-full mt-6 bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg transition"
            >
              {loading ? "Placing Order..." : "Place Order"}
            </button>
          </div>

        </div>
      </div>
    </main>
  );
}