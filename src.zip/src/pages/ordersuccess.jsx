import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../lib/apiClient";

export default function OrderSuccess({ setCartItems }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  // 🔥 Fetch Order Details
  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const res = await api.get(`/orders/${id}`);
        setOrder(res.data);
      } catch (err) {
        console.error("Order fetch error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchOrder();
  }, [id]);

  // ✅ ORDER AGAIN
  const handleOrderAgain = () => {
    if (!order) return;

    const reorderedItems = order.items.map((item) => ({
      _id: item.menuItem._id,
      name: item.menuItem.name,
      price: item.menuItem.price,
      quantity: item.quantity,
      image: item.menuItem.image || "",
    }));

    setCartItems(reorderedItems);
    localStorage.setItem("cart", JSON.stringify(reorderedItems));

    navigate("/cart");
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        Loading order details...
      </div>
    );
  }

  if (!order) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        No order found.
      </div>
    );
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-gray-100">
      <div className="bg-white shadow-2xl rounded-2xl p-10 max-w-md w-full text-center">

        {/* Success Icon */}
        <div className="text-5xl mb-4 animate-bounce">🎉</div>

        <h1 className="text-2xl font-bold text-green-600 mb-3">
          Order Placed Successfully!
        </h1>

        <p className="mb-2 text-gray-600">
          Order ID: <strong>#{order._id.slice(-6)}</strong>
        </p>

        <p className="mb-2">
          Total Paid: ₹{order.finalTotal || order.totalPrice}
        </p>

        <p className="mb-2">
          Payment Method: <strong>{order.paymentMethod}</strong>
        </p>

        <p className="mb-3">
          Status:
          <span className="ml-2 bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm">
            {order.status}
          </span>
        </p>

        {/* Real Estimated Delivery */}
        <p className="mt-2 text-gray-700">
          Estimated Delivery:
          <strong className="ml-1 text-green-600">
            {order.estimatedDeliveryTime
              ? new Date(order.estimatedDeliveryTime).toLocaleTimeString()
              : "30–40 mins"}
            {order.discount > 0 && (
              <p className="text-green-600 font-medium">
                Discount Applied: -₹{order.discount}
              </p>
            )}
          </strong>
        </p>

        {/* Delivery Address */}
        <div className="mt-5 text-left bg-gray-50 p-4 rounded-xl text-sm">
          <p className="font-semibold mb-1">Delivering to:</p>
          <p>{order.deliveryAddress.fullName}</p>
          <p>
            {order.deliveryAddress.house},{" "}
            {order.deliveryAddress.street}
          </p>
          <p>
            {order.deliveryAddress.area},{" "}
            {order.deliveryAddress.city}
          </p>
          <p>{order.deliveryAddress.pincode}</p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col gap-3 mt-6">

          {/* Track Order */}
          <button
            onClick={() => navigate(`/track-order/${order._id}`)}
            className="bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg transition"
          >
            Track Order 🚚
          </button>

          {/* View Orders */}
          <button
            onClick={() => navigate("/orders")}
            className="bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition"
          >
            View My Orders
          </button>

          {/* Order Again */}
          <button
            onClick={handleOrderAgain}
            className="bg-gray-800 hover:bg-black text-white py-2 rounded-lg transition"
          >
            Order Again
          </button>

        </div>

      </div>
    </main>
  );
}
