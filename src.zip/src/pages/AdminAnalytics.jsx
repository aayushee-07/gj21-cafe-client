import { useEffect, useState } from "react";
import api from "../lib/apiClient";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  ResponsiveContainer,
} from "recharts";

export default function AdminAnalytics() {
  const [data, setData] = useState([]);
  const [range, setRange] = useState("7");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [loading, setLoading] = useState(false);

  /* ===============================
     FETCH ANALYTICS
  =============================== */
  const fetchAnalytics = async () => {
    try {
      setLoading(true);

      let url = `/admin/analytics?range=${range}`;

      if (range === "custom" && startDate && endDate) {
        url = `/admin/analytics?startDate=${startDate}&endDate=${endDate}`;
      }

      const res = await api.get(url);
      setData(res.data || []);
    } catch (err) {
      console.error("Analytics fetch error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, [range]);

  /* ===============================
     UI
  =============================== */
  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-6">
        📊 Analytics Dashboard
      </h1>

      {/* ===============================
           FILTER SECTION
      =============================== */}
      <div className="bg-white p-4 rounded shadow mb-8">
        <h2 className="font-bold mb-4">Filter Analytics</h2>

        <div className="flex flex-wrap gap-4 items-center">
          <select
            value={range}
            onChange={(e) => setRange(e.target.value)}
            className="border px-3 py-2 rounded"
          >
            <option value="7">Last 7 Days</option>
            <option value="30">Last 30 Days</option>
            <option value="90">Last 90 Days</option>
            <option value="custom">Custom Range</option>
          </select>

          {range === "custom" && (
            <>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="border px-3 py-2 rounded"
              />
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="border px-3 py-2 rounded"
              />
              <button
                onClick={fetchAnalytics}
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
              >
                Apply
              </button>
            </>
          )}
        </div>
      </div>

      {loading ? (
        <div className="text-center py-10 text-gray-600">
          Loading analytics...
        </div>
      ) : (
        <>
          {/* ===============================
               ORDERS PER DAY
          =============================== */}
          <div className="bg-white p-4 rounded shadow mb-8">
            <h2 className="font-bold mb-4">Orders Per Day</h2>

            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="_id" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="orders"
                  stroke="#3b82f6"
                  strokeWidth={3}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* ===============================
               REVENUE PER DAY
          =============================== */}
          <div className="bg-white p-4 rounded shadow">
            <h2 className="font-bold mb-4">Revenue Per Day</h2>

            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="_id" />
                <YAxis />
                <Tooltip />
                <Bar
                  dataKey="revenue"
                  fill="#22c55e"
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </>
      )}
    </div>
  );
}