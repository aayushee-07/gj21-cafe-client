import { useEffect, useState } from "react";
import { FaHeart, FaRegHeart, FaShoppingCart } from "react-icons/fa";
import axios from "axios";
import { ToastContainer, toast, Slide } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Link } from "react-router-dom";

export default function Menu({
  user,
  addToCart,
  favorites,
  toggleFavorite,
  cartItems,
}) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortOption, setSortOption] = useState("");

  /* ===============================
     FETCH MENU (AUTO REFRESH ENABLED)
  =============================== */

  const fetchMenu = () => {
    axios
      .get("http://localhost:5001/api/menu")
      .then((res) => setItems(res.data || []))
      .catch((err) => console.error("❌ Error fetching menu:", err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchMenu();

    // 🔥 Auto refresh every 5 sec
    const interval = setInterval(fetchMenu, 5000);

    // 🔥 Refetch when tab becomes active
    const handleVisibility = () => {
      if (document.visibilityState === "visible") {
        fetchMenu();
      }
    };
    document.addEventListener("visibilitychange", handleVisibility);

    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", handleVisibility);
    };
  }, []);

  /* ===============================
     FILTERING + SORTING
  =============================== */

  const categories = ["All", ...new Set(items.map((item) => item.category))];

  let filteredItems =
    selectedCategory === "All"
      ? items
      : items.filter((item) => item.category === selectedCategory);

  if (searchTerm.trim()) {
    filteredItems = filteredItems.filter((item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }

  if (sortOption === "low-high")
    filteredItems.sort((a, b) => a.price - b.price);
  else if (sortOption === "high-low")
    filteredItems.sort((a, b) => b.price - a.price);
  else if (sortOption === "a-z")
    filteredItems.sort((a, b) => a.name.localeCompare(b.name));
  else if (sortOption === "z-a")
    filteredItems.sort((a, b) => b.name.localeCompare(a.name));

  const totalCartCount =
    cartItems?.reduce((sum, i) => sum + i.quantity, 0) || 0;

  /* ===============================
     LOADING STATES
  =============================== */

  if (loading)
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <p className="text-gray-600">Loading menu...</p>
      </div>
    );

  if (!items.length)
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <p className="text-gray-600">No menu items found.</p>
      </div>
    );

  /* ===============================
     UI STARTS
  =============================== */

  return (
    <main className="bg-gray-50 py-8 min-h-screen">
      <div className="w-full px-6">

        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold flex-1 text-center">
            Our Menu
          </h1>

          <div className="flex items-center gap-6 text-lg">
            <Link
              to="/favorites"
              className="flex items-center gap-1 text-red-500 hover:text-red-600"
            >
              <FaHeart className="text-2xl" />{" "}
              {favorites?.length || 0}
            </Link>

            <Link
              to="/cart"
              className="flex items-center gap-1 text-yellow-600 hover:text-yellow-700"
            >
              <FaShoppingCart className="text-2xl" />{" "}
              {totalCartCount}
            </Link>
          </div>
        </div>

        {/* Search + Sort */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
          <input
            type="search"
            placeholder="Search items..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full md:w-1/2 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          />

          <select
            value={sortOption}
            onChange={(e) => setSortOption(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500"
          >
            <option value="">Sort By</option>
            <option value="low-high">Price: Low to High</option>
            <option value="high-low">Price: High to Low</option>
            <option value="a-z">Name: A - Z</option>
            <option value="z-a">Name: Z - A</option>
          </select>
        </div>

        {/* Categories */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-10">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-lg font-medium border transition ${
                selectedCategory === cat
                  ? "bg-yellow-600 text-white border-yellow-600"
                  : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Menu Items */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
          {filteredItems.map((item) => {
            const isFav = favorites?.some(
              (fav) => fav._id === item._id
            );

            return (
              <article
                key={item._id}
                className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col transition hover:shadow-xl"
              >
                <div className="w-full aspect-square overflow-hidden relative">
                  <img
                    src={`http://localhost:5001${item.image}`}
                    alt={item.name}
                    className="w-full h-full object-cover"
                  />

                  {!item.isAvailable && (
                    <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                      <span className="text-white font-bold text-lg">
                        Out of Stock
                      </span>
                    </div>
                  )}
                </div>

                <div className="p-4 flex flex-col flex-grow">
                  <h3 className="text-lg font-semibold mb-1">
                    {item.name}
                  </h3>

                  {/* ✅ PRICE FIXED */}
                  <p className="text-yellow-600 font-bold mb-2 text-lg">
                    ₹{item.price}
                  </p>

                  <p className="text-gray-600 text-sm mb-4 flex-grow">
                    {item.description ||
                      "Delicious item from our menu."}
                  </p>

                  <div className="mt-auto flex items-center justify-between gap-2">
                    <button
                      onClick={() => toggleFavorite(item)}
                      className={`p-2 rounded-lg border transition ${
                        isFav
                          ? "bg-red-500 text-white"
                          : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                      }`}
                    >
                      {isFav ? <FaHeart /> : <FaRegHeart />}
                    </button>

                    {item.isAvailable ? (
                      <button
                        onClick={() => addToCart(item)}
                        className="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 flex items-center gap-2"
                      >
                        <FaShoppingCart /> Add
                      </button>
                    ) : (
                      <button
                        disabled
                        className="px-4 py-2 bg-gray-400 text-white rounded-lg cursor-not-allowed"
                      >
                        Out of Stock
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        <ToastContainer
          position="top-center"
          autoClose={3000}
          theme="colored"
          transition={Slide}
        />
      </div>
    </main>
  );
}
