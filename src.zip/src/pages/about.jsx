import React from "react";

const About = () => {
  return (
    <div className="max-w-5xl mx-auto px-6 py-16 text-center">
      <h2 className="text-3xl font-bold mb-6">About Us</h2>
      <p className="text-lg text-gray-700 leading-relaxed">
        Welcome to GJ 21 Cafe! We serve freshly brewed coffee, delicious snacks,
        and mouth-watering desserts. Our mission is to give you the perfect
        blend of taste and ambiance. Visit us and enjoy your time!
      </p>
    </div>
  );
};

export default About;
