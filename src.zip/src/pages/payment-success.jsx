import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import api from "../lib/apiClient";

export default function PaymentSuccess() {

  const [order, setOrder] = useState(null);
  const [params] = useSearchParams();

  const orderId = params.get("orderId");

  useEffect(() => {

    const updatePayment = async () => {
      try {

        await api.put(`/orders/mark-paid/${orderId}`);

        const res = await api.get(`/orders/${orderId}`);

        setOrder(res.data);

        localStorage.removeItem("cart");

      } catch (err) {
        console.log(err);
      }
    };

    if (orderId) updatePayment();

  }, [orderId]);

  if (!order) {
    return <div className="text-center mt-20">Loading...</div>;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center">

      <h1 className="text-3xl font-bold text-green-600 mb-6">
        Payment Successful 🎉
      </h1>

      <div className="bg-white shadow-lg rounded-lg p-6 w-[400px]">

        <p><b>Order ID:</b> {order._id}</p>
        <p><b>Payment Method:</b> ONLINE</p>
        <p><b>Status:</b> PAID</p>
        <p><b>Total:</b> ₹{order.finalTotal}</p>

        <hr className="my-3" />

        <h3 className="font-semibold mb-2">Items</h3>

        {order.items.map((item) => (
          <p key={item._id}>
            {item.menuItem.name} × {item.quantity}
          </p>
        ))}

      </div>

    </div>
  );
}