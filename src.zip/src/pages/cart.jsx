import React from "react";
import { useNavigate } from "react-router-dom";
import { FaPlus, FaMinus, FaTrash } from "react-icons/fa";

export default function Cart({
  cartItems,
  addToCart,
  removeFromCart,
  clearCart,
}) {
  const navigate = useNavigate();

  const totalPrice = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  if (!cartItems.length)
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center">
        <p className="text-gray-600 text-xl">
          Your cart is empty.
        </p>
      </div>
    );

  return (
    <main className="bg-gray-50 py-8 min-h-screen">
      <div className="container mx-auto px-6">
        <h1 className="text-3xl font-bold mb-6 text-center">
          Your Cart
        </h1>

        <div className="flex flex-col gap-6">
          {cartItems.map((item) => (
            <div
              key={item._id}
              className="flex flex-col md:flex-row items-center justify-between bg-white p-4 rounded-xl shadow-md"
            >
              {/* Item Info */}
              <div className="flex items-center gap-4 flex-1">
                <img
                  src={`http://localhost:5001${item.image}`}
                  alt={item.name}
                  className="w-24 h-24 object-cover rounded-lg"
                />
                <div>
                  <h3 className="text-lg font-semibold">
                    {item.name}
                  </h3>
                  <p className="text-gray-600">
                    ₹{item.price}
                  </p>
                </div>
              </div>

              {/* Quantity Controls */}
              <div className="flex items-center gap-3 mt-3 md:mt-0">
                <button
                  onClick={() =>
                    addToCart(item, true)
                  }
                  className="px-3 py-2 bg-gray-200 rounded-lg hover:bg-gray-300"
                >
                  <FaMinus />
                </button>

                <span className="font-bold">
                  {item.quantity}
                </span>

                <button
                  onClick={() => addToCart(item)}
                  className="px-3 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700"
                >
                  <FaPlus />
                </button>

                <button
                  onClick={() =>
                    removeFromCart(item._id)
                  }
                  className="px-3 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                >
                  <FaTrash />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="mt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <span className="text-xl font-bold">
            Total: ₹{totalPrice}
          </span>

          <div className="flex gap-4">
            <button
              onClick={clearCart}
              className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
            >
              Clear Cart
            </button>

            <button
              onClick={() => navigate("/checkout")}
              className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg"
            >
              Checkout
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}