import { Link } from "react-router-dom";
import cafeImage from "/gj21-cafe-logo.jpeg";

function Home() {
  return (
    <section className="bg-black text-white min-h-screen flex items-center">
      <div className="container mx-auto px-6 md:px-12 grid md:grid-cols-2 items-center gap-8">

        {/* Left Text */}
        <div className="space-y-6">
          <h1 className="text-5xl md:text-6xl font-bold">
            Welcome to GJ 21 Cafe
          </h1>        
          <p className="text-2xl md:text-3xl font-semibold">
            Where every sip tells a story ☕✨
          </p>
          <Link
            to="/menu"
            className="bg-amber-600 hover:bg-[#6a4f4b] text-white font-bold px-8 py-4 rounded-lg text-lg md:text-xl"
          >
            Order Now
          </Link>
        </div>

        {/* Right Image */}
        <div className="flex justify-center md:justify-end">
          <img
            src={cafeImage}
            alt="Cafe Logo"
            className="max-h-[70vh] w-auto object-contain"
          />
        </div>
      </div>
    </section>
  );
}

export default Home;
