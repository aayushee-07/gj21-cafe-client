import React, { useEffect, useState, useRef } from "react";
import api from "../lib/apiClient";
import { Link } from "react-router-dom";


export default function AdminDashboard() {
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState({});
  const [menu, setMenu] = useState([]);
  const [cancelModal, setCancelModal] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [cancelReason, setCancelReason] = useState("");
  const [filter, setFilter] = useState("all");
  const [menuCategoryFilter, setMenuCategoryFilter] = useState("all");
  const [categorySearch, setCategorySearch] = useState("");
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [ratingFilter, setRatingFilter] = useState("all");
  const [ratingPage, setRatingPage] = useState(1);


  const [editingId, setEditingId] = useState(null);
  const [editedItem, setEditedItem] = useState({});
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalOrders, setTotalOrders] = useState(0);
  const [menuPage, setMenuPage] = useState(1);
  const ratingsPerPage = 5;
  const [menuTotalPages, setMenuTotalPages] = useState(1);
  const [menuSearch, setMenuSearch] = useState("");

  const previousCount = useRef(0);

  const [newItem, setNewItem] = useState({
    name: "",
    price: "",
    description: "",
    category: "",
    image: null,
  });

  /* ================= FETCH ================= */
  // Fetch when page changes
  useEffect(() => {
    fetchAll();
  }, [page, menuPage, menuCategoryFilter]);

  // Auto refresh every 10 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchAll();
    }, 10000);

    return () => clearInterval(interval);
  }, [page, menuPage, menuCategoryFilter]);

  const fetchAll = async () => {
    try {
      const [orderRes, statsRes, menuRes] = await Promise.all([
        api.get(`/admin/orders?page=${page}&limit=10`),
        api.get("/admin/stats"),
        api.get(
          `/admin/menu?page=${menuPage}&limit=6&search=${menuSearch}&category=${menuCategoryFilter}`
        )
      ]);

      const orderData = orderRes.data.orders;

      if (orderData.length > previousCount.current) {
        if (previousCount.current !== 0) {
          new Audio(
            "https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg"
          ).play();
        }
      }

      previousCount.current = orderData.length;

      setOrders(orderData);
      setTotalPages(orderRes.data.totalPages);
      setTotalOrders(orderRes.data.totalOrders);
      setStats(statsRes.data);
      setMenu(menuRes.data.menu);
      setMenuTotalPages(menuRes.data.totalPages);
    } catch (err) {
      console.error(err);
    }
  };

  /* ================= ORDER STATUS ================= */
  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "confirmed":
        return "bg-blue-100 text-blue-700";
      case "preparing":
        return "bg-purple-100 text-purple-700";
      case "delivered":
        return "bg-green-100 text-green-700";
      case "cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const updateStatus = async (id, status) => {
    await api.put(`/admin/orders/${id}/status`, { status });
    fetchAll();
  };

  const filteredOrders =
    filter === "all"
      ? orders
      : orders.filter((o) => o.status === filter);

  /* ================= RATING LOGIC ================= */

  const ratedOrders = orders.filter((order) => order.rating);

  const filteredRatedOrders =
    ratingFilter === "all"
      ? ratedOrders
      : ratedOrders.filter(
        (order) => order.rating === Number(ratingFilter)
      );

  const averageRating =
    ratedOrders.length > 0
      ? (
        ratedOrders.reduce((acc, o) => acc + o.rating, 0) /
        ratedOrders.length
      ).toFixed(1)
      : 0;

  /* ===== Rating Pagination ===== */

  const totalRatingPages =
    Math.ceil(filteredRatedOrders.length / ratingsPerPage) || 1;

  const startIndex = (ratingPage - 1) * ratingsPerPage;

  const paginatedRatings = filteredRatedOrders.slice(
    startIndex,
    startIndex + ratingsPerPage
  );
  /* ================= MENU CRUD ================= */

  const handleAddItem = async () => {
    const formData = new FormData();
    Object.keys(newItem).forEach((key) =>
      formData.append(key, newItem[key])
    );

    await api.post("/admin/menu", formData, {
      headers: { "Content-Type": "multipart/form-data" },
    });

    setNewItem({
      name: "",
      price: "",
      description: "",
      category: "",
      image: null,
    });

    fetchAll();
  };

  const deleteItem = async (id) => {
    if (!window.confirm("Delete this item?")) return;
    await api.delete(`/admin/menu/${id}`);
    fetchAll();
  };

  const startEdit = (item) => {
    setEditingId(item._id);
    setEditedItem({ ...item });
  };

  const saveEdit = async () => {
    await api.put(`/admin/menu/${editingId}`, editedItem);
    setEditingId(null);
    fetchAll();
  };

  const toggleStock = async (id) => {
    await api.put(`/admin/menu/${id}/toggle`);
    fetchAll();
  };

  const categories = [
    "all",
    "coldcoffee",
    "chai",
    "hotcoffee",
    "milkshakes",
    "fries",
    "bites",
    "garlic-bread",
    "burgers",
    "sandwiches",
    "pasta",
    "pizza",
    "frankie",
    "bournvita",
    "juice",
    "maggie"

  ];
  const filteredCategories = categories.filter((cat) =>
    cat.toLowerCase().includes(categorySearch.toLowerCase())
  );

  return (
    <main className="p-8 bg-gradient-to-br from-gray-50 to-gray-200 min-h-screen">
      <h1 className="text-3xl font-bold mb-8 text-gray-800">
        👑 GJ21 Cafe Admin Dashboard
      </h1>
      <Link
        to="/admin/analytics"
        className="bg-purple-600 hover:bg-purple-700 text-white px-5 py-2 rounded-lg shadow-md transition"
      >
        📊 View Analytics
      </Link>


      <Link
        to="/admin/coupons"
        className="bg-purple-600 text-white px-5 py-2 rounded-lg shadow-md hover:bg-purple-700 transition ml-2"
      >
        Manage Coupons
      </Link>

      {/* ================= STATS ================= */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        <Stat title="Total Orders" value={stats.totalOrders} color="blue" />
        <Stat title="Pending" value={stats.pending} color="yellow" />
        <Stat title="Preparing" value={stats.preparing} color="purple" />
        <Stat title="Revenue" value={`₹${stats.revenue || 0}`} color="green" />
        <Stat title="Avg Rating" value={`⭐ ${averageRating}`} color="yellow" />
      </div>

      {/* ================= CUSTOMER FEEDBACK ================= */}
      <div className="bg-white p-6 rounded-xl shadow-md mt-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="font-bold text-lg">⭐ Customer Feedback</h2>

          <select
            value={ratingFilter}
            onChange={(e) => setRatingFilter(e.target.value)}
            className="border p-2 rounded"
          >
            <option value="all">All Ratings</option>
            <option value="5">5 Star</option>
            <option value="4">4 Star</option>
            <option value="3">3 Star</option>
            <option value="2">2 Star</option>
            <option value="1">1 Star</option>
          </select>
        </div>

        {filteredRatedOrders.length === 0 ? (
          <p className="text-gray-500">No feedback available.</p>
        ) : (
          <div className="space-y-4">
            {paginatedRatings.map((order) => (
              <div
                key={order._id}
                className={`p-4 rounded-xl shadow-sm hover:shadow-md transition ${order.rating <= 2
                  ? "bg-red-50 border-red-300"
                  : "bg-gray-50"
                  }`}
              >
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-semibold">
                      {order.deliveryAddress?.fullName}
                    </p>
                    <p className="text-sm text-gray-500">
                      Order #{order._id.slice(-6)}
                    </p>
                  </div>

                  <div className="text-yellow-500 text-lg">
                    {"⭐".repeat(order.rating)}
                  </div>
                </div>

                {order.review && (
                  <p className="mt-2 text-gray-700 italic">
                    "{order.review}"
                  </p>
                )}

                {order.ratedAt && (
                  <p className="text-xs text-gray-400 mt-2">
                    Rated on:{" "}
                    {new Date(order.ratedAt).toLocaleString()}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Rating Pagination */}
      <div className="flex justify-center items-center gap-3 mt-6">

        <button
          disabled={ratingPage === 1}
          onClick={() => setRatingPage(ratingPage - 1)}
          className="px-3 py-1 bg-gray-200 rounded disabled:opacity-40"
        >
          Prev
        </button>

        <span className="font-semibold">
          Page {ratingPage} of {totalRatingPages || 1}
        </span>

        <button
          disabled={ratingPage === totalRatingPages}
          onClick={() => setRatingPage(ratingPage + 1)}
          className="px-3 py-1 bg-gray-200 rounded disabled:opacity-40"
        >
          Next
        </button>

      </div>
      {/* ================= ORDERS ================= */}
      <div className="bg-white p-4 rounded shadow mb-8">
        <div className="flex justify-between mb-4">
          <h2 className="font-bold text-lg">Orders</h2>
          <select
            className="border p-2 rounded"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All</option>
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="preparing">Preparing</option>
            <option value="out_for_delivery">Out for Delivery</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>

        <table className="w-full text-sm text-left border-collapse">
          <thead className="bg-gray-800 text-white">
            <tr>
              <th className="p-3">Order</th>
              <th className="p-3">Customer</th>
              <th className="p-3">Total</th>
              <th className="p-3">Status</th>
              <th className="p-3">Update</th>
              <th className="p-3">View</th>
            </tr>
          </thead>

          <tbody>
            {filteredOrders.map((order) => (
              <tr key={order._id} className="border-t hover:bg-gray-50 transition">
                <td className="p-3">#{order._id.slice(-6)}</td>
                <td className="p-3">{order.deliveryAddress?.fullName}</td>
                <td className="p-3">₹{order.totalPrice}</td>
                <td className="p-3">
                  <span className={`px-3 py-1 rounded-full text-xs ${getStatusColor(order.status)}`}>
                    {order.status}
                  </span>
                </td>
                <td className="p-3 flex flex-col gap-2 items-center">

                  {order.status !== "cancelled" && (
                    <>
                      <select
                        value={order.status}
                        onChange={(e) =>
                          updateStatus(order._id, e.target.value)
                        }
                        className="border p-1 rounded"
                      >
                        <option value="pending">Pending</option>
                        <option value="confirmed">Confirmed</option>
                        <option value="preparing">Preparing</option>
                        <option value="out_for_delivery">out for delivery</option>
                        <option value="delivered">Delivered</option>
                      </select>

                      <button
                        onClick={() => {
                          setSelectedOrderId(order._id);
                          setCancelModal(true);
                        }}
                        className="bg-red-600 text-white px-3 py-1 rounded"
                      >
                        Cancel
                      </button>
                    </>
                  )}

                  {order.status === "cancelled" && (
                    <span className="text-red-600 font-semibold">
                      Cancelled
                    </span>
                  )}

                </td>
                <td className="p-3">
                  <button
                    onClick={() => setSelectedOrder(order)}
                    className="bg-blue-600 text-white px-3 py-1 rounded"
                  >
                    View
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* ================= PAGINATION ================= */}
        <div className="flex justify-center items-center gap-4 mt-6">

          <button
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
            className="px-3 py-1 bg-gray-300 rounded disabled:opacity-50"
          >
            Prev
          </button>

          <span className="font-semibold">
            Page {page} of {totalPages}
          </span>

          <button
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
            className="px-3 py-1 bg-gray-300 rounded disabled:opacity-50"
          >
            Next
          </button>
        </div>
      </div>

      {/* ================= VIEW MODAL ================= */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded w-full max-w-lg max-h-[90vh] overflow-y-auto">

            <h2 className="font-bold text-xl mb-3">
              Order #{selectedOrder._id.slice(-6)}
            </h2>

            <p><strong>Name:</strong> {selectedOrder.deliveryAddress?.fullName}</p>
            <p><strong>Email:</strong> {selectedOrder.user?.email}</p>
            <p><strong>Phone:</strong> {selectedOrder.deliveryAddress?.phone}</p>

            <hr className="my-3" />

            <p><strong>Address:</strong></p>
            <p>{selectedOrder.deliveryAddress?.house}</p>
            <p>{selectedOrder.deliveryAddress?.street}</p>
            <p>{selectedOrder.deliveryAddress?.area}</p>
            <p>{selectedOrder.deliveryAddress?.city}</p>
            <p>{selectedOrder.deliveryAddress?.pincode}</p>
            <p>{selectedOrder.deliveryAddress?.landmark}</p>

            <hr className="my-3" />

            <p><strong>Payment:</strong> {selectedOrder.paymentMethod}</p>
            <p><strong>Status:</strong> {selectedOrder.paymentStatus}</p>

            <hr className="my-3" />

            <p className="font-semibold">Items:</p>
            {selectedOrder.items.map((item, i) => (
              <p key={i}>
                {item.menuItem?.name} × {item.quantity}
              </p>
            ))}

            <hr className="my-3" />

            <p><strong>Subtotal:</strong> ₹{selectedOrder.subtotal}</p>
            <p><strong>Delivery:</strong> ₹{selectedOrder.deliveryFee}</p>

            {selectedOrder.discount > 0 && (
              <p className="text-green-600">
                <strong>Discount:</strong> -₹{selectedOrder.discount}
              </p>
            )}

            <p className="font-bold">
              <strong>Final Total:</strong> ₹
              {selectedOrder.finalTotal || selectedOrder.totalPrice}
            </p>

            <p>
              <strong>Estimated Delivery:</strong>{" "}
              {new Date(
                new Date(selectedOrder.createdAt).getTime() + 45 * 60000
              ).toLocaleString("en-IN")}
            </p>

            <button
              className="mt-4 bg-gray-700 text-white px-4 py-2 rounded"
              onClick={() => setSelectedOrder(null)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ================= MENU MANAGEMENT ================= */}

      <div className="bg-white p-6 rounded shadow mt-8">
        <h2 className="font-bold text-lg mb-6">Menu Management</h2>

        {/* ADD ITEM */}
        <div className="bg-white p-6 rounded-xl shadow-md mt-8">
          <h3 className="font-semibold mb-4">Add New Item</h3>

          <div className="grid md:grid-cols-5 gap-3 mb-4">
            <input placeholder="Name" value={newItem.name}
              onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
              className="border p-2 rounded" />

            <input type="number" placeholder="Price" value={newItem.price}
              onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
              className="border p-2 rounded" />

            <input placeholder="Category" value={newItem.category}
              onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
              className="border p-2 rounded" />

            <input placeholder="Description" value={newItem.description}
              onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
              className="border p-2 rounded" />

            <input type="file" accept="image/*"
              onChange={(e) => setNewItem({ ...newItem, image: e.target.files[0] })}
              className="border p-2 rounded" />
          </div>

          <button onClick={handleAddItem}
            className="bg-green-600 text-white px-4 py-2 rounded">
            Add Item
          </button>
        </div>

        {/* CATEGORY FILTER */}
        <div className="mb-6">
          <div className="mb-6 space-y-3">

            {/* Search Category */}
            <input
              type="text"
              placeholder="Search category..."
              value={categorySearch}
              onChange={(e) => setCategorySearch(e.target.value)}
              className="border p-2 rounded w-full md:w-64"
            />

            {/* Category Select */}
            <select
              className="border p-2 rounded"
              value={menuCategoryFilter}
              onChange={(e) => setMenuCategoryFilter(e.target.value)}
            >
              {filteredCategories.map((cat, i) => (
                <option key={i} value={cat}>
                  {cat.toUpperCase()}
                </option>
              ))}
            </select>

          </div>
        </div>

        {/* ================= MENU LIST ================= */}

        <div className="grid md:grid-cols-3 gap-4">
          {menu.map((item) => (
            <div key={item._id} className="bg-white p-4 rounded-xl shadow-md hover:shadow-lg transition">

              {editingId === item._id ? (
                <>
                  <input
                    value={editedItem.name}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem, name: e.target.value })
                    }
                    className="border p-1 w-full mb-2"
                  />
                  {item.image && (
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-32 object-cover rounded mb-2"
                    />
                  )}

                  <input
                    value={editedItem.category}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem, category: e.target.value })
                    }
                    className="border p-1 w-full mb-2"
                  />

                  <textarea
                    value={editedItem.description}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem, description: e.target.value })
                    }
                    className="border p-1 w-full mb-2"
                  />

                  <input
                    type="number"
                    value={editedItem.price}
                    onChange={(e) =>
                      setEditedItem({ ...editedItem, price: e.target.value })
                    }
                    className="border p-1 w-full mb-2"
                  />

                  <button
                    onClick={saveEdit}
                   className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-lg transition"
                  >
                    Save
                  </button>

                  <button
                    onClick={() => setEditingId(null)}
                    className="bg-gray-400 text-white px-2 py-1 rounded"
                  >
                    Cancel
                  </button>
                </>
              ) : (
                <>
                  <p className="text-xs text-gray-500 mb-1">
                    {item.category?.toUpperCase()}
                  </p>

                  <h4 className="font-semibold">{item.name}</h4>
                  <p className="text-sm text-gray-600">{item.description}</p>
                  <p className="my-2 font-bold">₹{item.price}</p>

                  <div className="flex gap-2">
                    <button
                      onClick={() => startEdit(item)}
                      className="bg-yellow-500 text-white px-2 py-1 rounded"
                    >
                      Edit
                    </button>

                    <button
                      onClick={() => deleteItem(item._id)}
                      className="bg-red-600 text-white px-2 py-1 rounded"
                    >
                      Delete
                    </button>

                    <button
                      onClick={() => toggleStock(item._id)}
                      className={`px-2 py-1 rounded ${item.isAvailable
                        ? "bg-green-600 text-white"
                        : "bg-red-600 text-white"
                        }`}
                    >
                      {item.isAvailable ? "Available" : "Out of Stock"}
                    </button>
                  </div>
                </>
              )}

            </div>
          ))}
        </div>
        {/* ================= MENU PAGINATION ================= */}
        <div className="flex justify-center mt-8">

          <div className="flex items-center gap-2 bg-white shadow-md px-4 py-2 rounded-lg">

            {/* Prev Button */}
            <button
              disabled={menuPage === 1}
              onClick={() => setMenuPage(menuPage - 1)}
              className={`px-3 py-1 rounded-md text-sm font-medium transition 
        ${menuPage === 1
                  ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                  : "bg-gray-100 hover:bg-gray-200"
                }`}
            >
              Prev
            </button>

            {/* Page Numbers */}
            {Array.from({ length: menuTotalPages }, (_, i) => i + 1)
              .slice(
                Math.max(menuPage - 2, 0),
                Math.min(menuPage + 1, menuTotalPages)
              )
              .map((number) => (
                <button
                  key={number}
                  onClick={() => setMenuPage(number)}
                  className={`px-3 py-1 rounded-md text-sm font-medium transition 
            ${menuPage === number
                      ? "bg-purple-600 text-white"
                      : "bg-gray-100 hover:bg-gray-200"
                    }`}
                >
                  {number}
                </button>
              ))}

            {/* Next Button */}
            <button
              disabled={menuPage === menuTotalPages}
              onClick={() => setMenuPage(menuPage + 1)}
              className={`px-3 py-1 rounded-md text-sm font-medium transition 
        ${menuPage === menuTotalPages
                  ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                  : "bg-gray-100 hover:bg-gray-200"
                }`}
            >
              Next
            </button>

          </div>
        </div>
      </div>
      {/* ================= CANCEL MODAL ================= */}
      {cancelModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-96">

            <h2 className="text-lg font-bold mb-4">
              Cancel Order
            </h2>

            <textarea
              placeholder="Enter cancellation reason (required)"
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              className="w-full border p-2 rounded mb-4"
            />

            <div className="flex justify-end gap-2">

              <button
                onClick={() => {
                  setCancelModal(false);
                  setCancelReason("");
                }}
                className="px-4 py-1 bg-gray-400 text-white rounded"
              >
                Close
              </button>

              <button
                onClick={async () => {
                  if (!cancelReason.trim()) {
                    alert("Cancel reason required");
                    return;
                  }

                  await api.put(
                    `/admin/orders/${selectedOrderId}/cancel`,
                    { reason: cancelReason }
                  );

                  setCancelModal(false);
                  setCancelReason("");
                  fetchAll();
                }}
                className="px-4 py-1 bg-red-600 text-white rounded"
              >
                Confirm Cancel
              </button>

            </div>

          </div>
        </div>
      )}

    </main>
  );
}
function Stat({ title, value, color }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition text-center">
      <p>{title}</p>
      <h2 className={`text-3xl font-bold text-${color}-600`}>
        {value || 0}
      </h2>
    </div>
  );
}
