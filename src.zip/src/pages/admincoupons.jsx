import { useEffect, useState } from "react";
import api from "../lib/apiClient";

export default function AdminCoupons() {
  const [coupons, setCoupons] = useState([]);
  const [loading, setLoading] = useState(false);

  const [deleteModal, setDeleteModal] = useState(false);
  const [selectedCouponId, setSelectedCouponId] = useState(null);

  const [form, setForm] = useState({
    code: "",
    discountType: "percentage",
    discountValue: "",
    minOrderAmount: "",
    startDate: "",
    expiryDate: "",
  });

  /* ===============================
     FETCH COUPONS
  =============================== */
  const fetchCoupons = async () => {
    try {
      setLoading(true);
      const res = await api.get("/coupons");
      setCoupons(res.data);
    } catch (err) {
      console.error("Fetch coupon error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  /* ===============================
     CREATE COUPON
  =============================== */
  const handleSubmit = async () => {
    try {
      await api.post("/coupons", form);

      setForm({
        code: "",
        discountType: "percentage",
        discountValue: "",
        minOrderAmount: "",
        startDate: "",
        expiryDate: "",
      });

      fetchCoupons();
    } catch (err) {
      console.error(err.response?.data?.message || "Error creating coupon");
    }
  };

  /* ===============================
     TOGGLE ACTIVE
  =============================== */
  const toggleCoupon = async (id) => {
    await api.put(`/coupons/${id}/toggle`);
    fetchCoupons();
  };

  /* ===============================
     DELETE COUPON (CUSTOM MODAL)
  =============================== */
  const openDeleteModal = (id) => {
    setSelectedCouponId(id);
    setDeleteModal(true);
  };

  const confirmDelete = async () => {
    await api.delete(`/coupons/${selectedCouponId}`);
    setDeleteModal(false);
    setSelectedCouponId(null);
    fetchCoupons();
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-2xl font-bold mb-6">
        🎟 Coupon Management
      </h1>

      {/* ===============================
           CREATE COUPON FORM
      =============================== */}
      <div className="bg-white p-6 rounded shadow mb-8">
        <h2 className="font-semibold mb-4">Create Coupon</h2>

        <div className="grid md:grid-cols-3 gap-4">
          <input
            placeholder="Coupon Code"
            value={form.code}
            onChange={(e) =>
              setForm({ ...form, code: e.target.value })
            }
            className="border p-2 rounded"
          />

          <select
            value={form.discountType}
            onChange={(e) =>
              setForm({
                ...form,
                discountType: e.target.value,
              })
            }
            className="border p-2 rounded"
          >
            <option value="percentage">
              Percentage (%)
            </option>
            <option value="flat">
              Flat (₹)
            </option>
          </select>

          <input
            type="number"
            placeholder="Discount Value"
            value={form.discountValue}
            onChange={(e) =>
              setForm({
                ...form,
                discountValue: e.target.value,
              })
            }
            className="border p-2 rounded"
          />

          <input
            type="number"
            placeholder="Minimum Order Amount"
            value={form.minOrderAmount}
            onChange={(e) =>
              setForm({
                ...form,
                minOrderAmount: e.target.value,
              })
            }
            className="border p-2 rounded"
          />

          {/* ✅ START DATE ADDED */}
          <input
            type="date"
            value={form.startDate}
            onChange={(e) =>
              setForm({
                ...form,
                startDate: e.target.value,
              })
            }
            className="border p-2 rounded"
          />

          <input
            type="date"
            value={form.expiryDate}
            onChange={(e) =>
              setForm({
                ...form,
                expiryDate: e.target.value,
              })
            }
            className="border p-2 rounded"
          />
        </div>

        <button
          onClick={handleSubmit}
          className="mt-4 bg-green-600 text-white px-4 py-2 rounded"
        >
          Add Coupon
        </button>
      </div>

      {/* ===============================
           COUPON TABLE
      =============================== */}
      <div className="bg-white p-6 rounded shadow">
        <h2 className="font-semibold mb-4">
          All Coupons
        </h2>

        {loading ? (
          <p>Loading...</p>
        ) : (
          <table className="w-full text-sm text-center">
            <thead className="bg-gray-200">
              <tr>
                <th className="p-3">Code</th>
                <th className="p-3">Type</th>
                <th className="p-3">Value</th>
                <th className="p-3">Min Order</th>
                <th className="p-3">Start</th>
                <th className="p-3">Expiry</th>
                <th className="p-3">Status</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>

            <tbody>
              {coupons.map((c) => (
                <tr key={c._id} className="border-t">
                  <td className="p-3 font-semibold">
                    {c.code}
                  </td>

                  <td className="p-3">
                    {c.discountType}
                  </td>

                  <td className="p-3">
                    {c.discountValue}
                    {c.discountType === "percentage"
                      ? "%"
                      : "₹"}
                  </td>

                  <td className="p-3">
                    ₹{c.minOrderAmount}
                  </td>

                  {/* ✅ SHOW START DATE */}
                  <td className="p-3">
                    {c.startDate
                      ? new Date(
                        c.startDate
                      ).toLocaleDateString()
                      : "-"}
                  </td>

                  <td className="p-3">
                    {new Date(
                      c.expiryDate
                    ).toLocaleDateString()}
                  </td>

                  <td className="p-3">
                    <span
                      className={`px-3 py-1 rounded text-white ${c.isActive
                          ? "bg-green-600"
                          : "bg-red-600"
                        }`}
                    >
                      {c.isActive
                        ? "Active"
                        : "Inactive"}
                    </span>
                  </td>

                  <td className="p-3 flex justify-center gap-2">
                    <button
                      onClick={() =>
                        toggleCoupon(c._id)
                      }
                      className="bg-blue-600 text-white px-3 py-1 rounded"
                    >
                      Toggle
                    </button>

                    <button
                      onClick={() =>
                        openDeleteModal(c._id)
                      }
                      className="bg-red-600 text-white px-3 py-1 rounded"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* ===============================
           DELETE MODAL (CUSTOM)
      =============================== */}
      {deleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg w-96">

            <h2 className="text-lg font-bold mb-4">
              Delete Coupon
            </h2>

            <p className="mb-4 text-gray-600">
              Are you sure you want to delete this coupon?
              This action cannot be undone.
            </p>

            <div className="flex justify-end gap-3">
              <button
                onClick={() => {
                  setDeleteModal(false);
                  setSelectedCouponId(null);
                }}
                className="px-4 py-1 bg-gray-400 text-white rounded"
              >
                Cancel
              </button>

              <button
                onClick={confirmDelete}
                className="px-4 py-1 bg-red-600 text-white rounded"
              >
                Delete
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}