import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../lib/apiClient";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function OrderHistory() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // ⭐ Rating States
  const [ratingModal, setRatingModal] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState("");

  // ================= FETCH ORDERS =================
  const fetchOrders = async () => {
    try {
      const res = await api.get("/orders");
      setOrders(res.data);
    } catch (err) {
      toast.error("Failed to fetch orders");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  // ================= OPEN RATING MODAL =================
  const openRatingModal = (id) => {
    setSelectedOrderId(id);
    setRating(0);
    setReview("");
    setRatingModal(true);
  };

  // ================= SUBMIT RATING =================
  const submitRating = async () => {
    if (rating === 0) {
      toast.error("Please select a rating ⭐");
      return;
    }

    try {
      await api.put(`/orders/${selectedOrderId}/rate`, {
        rating,
        review,
      });

      toast.success("Thank you for your feedback!");

      setRatingModal(false);
      setSelectedOrderId(null);
      setRating(0);
      setReview("");

      fetchOrders(); // refresh list
    } catch (err) {
      toast.error("Failed to submit rating");
    }
  };

  // ================= CANCEL ORDER =================
  const handleCancel = async (orderId) => {
    try {
      await api.put(`/orders/${orderId}/cancel`);
      fetchOrders();
      toast.success("Order cancelled successfully!");
    } catch (err) {
      toast.error(
        err.response?.data?.message || "Cannot cancel this order"
      );
    }
  };

  // ================= REORDER =================
  const handleReorder = async (order) => {
    try {
      const cartItems = order.items.map((item) => ({
        _id: item.menuItem._id,
        name: item.menuItem.name,
        price: item.menuItem.price,
        quantity: item.quantity,
      }));

      localStorage.setItem("reorderCart", JSON.stringify(cartItems));

      toast.success("Items added to cart!");
      navigate("/cart");
    } catch (err) {
      toast.error("Reorder failed");
    }
  };

  if (loading)
    return <p className="text-center mt-10">Loading your orders...</p>;

  if (orders.length === 0)
    return (
      <p className="text-center mt-10 text-gray-600 text-lg">
        You have no orders 📭
      </p>
    );

  return (
    <main className="bg-white min-h-[80vh] py-8">
      <ToastContainer />
      <div className="max-w-3xl mx-auto px-6">
        <h1 className="text-3xl font-bold mb-6">📜 Order History</h1>

        <div className="space-y-6">
          {orders.map((order) => (
            <div
              key={order._id}
              className="border rounded-lg p-4 shadow bg-gray-50"
            >
              {/* HEADER */}
              <div className="flex justify-between items-center mb-2">
                <h2 className="font-semibold text-lg">
                  Order #{order._id.slice(-6)}
                </h2>

                <span
                  className={`px-3 py-1 rounded text-white text-sm ${
                    order.status === "pending"
                      ? "bg-yellow-500"
                      : order.status === "confirmed"
                      ? "bg-blue-500"
                      : order.status === "preparing"
                      ? "bg-purple-500"
                      : order.status === "out_for_delivery"
                      ? "bg-indigo-600"
                      : order.status === "delivered"
                      ? "bg-green-600"
                      : order.status === "cancelled"
                      ? "bg-red-600"
                      : "bg-gray-500"
                  }`}
                >
                  {order.status.replace(/_/g, " ")}
                </span>
              </div>

              <p className="text-sm text-gray-600 mb-2">
                Date: {new Date(order.createdAt).toLocaleString()}
              </p>

              {/* CANCEL INFO */}
              {order.status === "cancelled" && (
                <div className="mb-4 bg-red-50 border border-red-200 p-3 rounded text-red-700 text-sm">
                  <p className="font-semibold text-base mb-1">
                    ❌ Order Cancelled
                  </p>
                  {order.cancelReason && (
                    <p><strong>Reason:</strong> {order.cancelReason}</p>
                  )}
                  {order.cancelledBy && (
                    <p><strong>Cancelled By:</strong> {order.cancelledBy}</p>
                  )}
                </div>
              )}

              {/* ITEMS */}
              <ul className="space-y-1">
                {order.items.map((it) => (
                  <li key={it._id} className="flex justify-between">
                    <span>
                      {it.menuItem?.name} × {it.quantity}
                    </span>
                    <span>
                      ₹{it.menuItem?.price * it.quantity}
                    </span>
                  </li>
                ))}
              </ul>

              {/* BILL */}
              <div className="mt-3 space-y-1">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>₹{order.subtotal}</span>
                </div>

                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>₹{order.deliveryFee}</span>
                </div>

                {order.discount > 0 && (
                  <div className="flex justify-between text-green-600 font-medium">
                    <span>Discount ({order.couponCode})</span>
                    <span>-₹{order.discount}</span>
                  </div>
                )}

                <hr className="my-2 border-gray-300" />

                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <span>
                    ₹{order.finalTotal || order.totalPrice}
                  </span>
                </div>
              </div>

              {/* SHOW RATING AFTER SUBMITTED */}
              {order.rating && (
                <div className="mt-3">
                  <div className="text-yellow-500 text-lg">
                    {"★".repeat(order.rating)}
                  </div>
                  {order.review && (
                    <p className="text-sm text-gray-600 mt-1">
                      "{order.review}"
                    </p>
                  )}
                </div>
              )}

              {/* ACTION BUTTONS */}
              <div className="mt-4 flex justify-end gap-3">

                {order.status === "pending" && (
                  <button
                    onClick={() => handleCancel(order._id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded"
                  >
                    Cancel Order
                  </button>
                )}

                {order.status === "delivered" && !order.rating && (
                  <button
                    onClick={() => openRatingModal(order._id)}
                    className="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-1 rounded"
                  >
                    ⭐ Rate Order
                  </button>
                )}

                <button
                  onClick={() => handleReorder(order)}
                  className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-1 rounded"
                >
                  Reorder
                </button>

                {order.status !== "cancelled" && (
                  <button
                    onClick={() => navigate(`/track-order/${order._id}`)}
                    className="bg-green-500 hover:bg-green-600 text-white px-4 py-1 rounded"
                  >
                    Track Order
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RATING MODAL */}
      {ratingModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded w-96">

            <h2 className="text-lg font-bold mb-4">
              Rate Your Order
            </h2>

            <div className="flex justify-center mb-4">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  onClick={() => setRating(star)}
                  className={`text-3xl cursor-pointer ${
                    star <= rating ? "text-yellow-500" : "text-gray-300"
                  }`}
                >
                  ★
                </span>
              ))}
            </div>

            <textarea
              placeholder="Write a review (optional)"
              value={review}
              onChange={(e) => setReview(e.target.value)}
              className="w-full border p-2 rounded mb-4"
            />

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setRatingModal(false)}
                className="bg-gray-400 text-white px-3 py-1 rounded"
              >
                Cancel
              </button>

              <button
                onClick={submitRating}
                className="bg-green-600 text-white px-3 py-1 rounded"
              >
                Submit
              </button>
            </div>

          </div>
        </div>
      )}
    </main>
  );
}