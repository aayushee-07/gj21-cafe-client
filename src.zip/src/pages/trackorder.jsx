import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../lib/apiClient";

export default function TrackOrder() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);

  useEffect(() => {
    fetchOrder();

    const interval = setInterval(() => {
      fetchOrder();
    }, 5000);

    return () => clearInterval(interval);
  }, [id]);

  const fetchOrder = async () => {
    try {
      const res = await api.get(`/orders/${id}`);
      setOrder(res.data);
    } catch (err) {
      console.error("Track error:", err);
    }
  };

  if (!order) {
    return (
      <div className="text-center mt-10">
        Loading order details...
      </div>
    );
  }

  const statusSteps = [
    "pending",
    "confirmed",
    "preparing",
    "out_for_delivery",
    "delivered",
  ];

  const currentStep = statusSteps.indexOf(order.status);

  // 🔥 Status Color Function
  const getStatusColor = (status) => {
    switch (status) {
      case "pending":
        return "bg-yellow-500";
      case "confirmed":
        return "bg-blue-500";
      case "preparing":
        return "bg-purple-500";
      case "out_for_delivery":
        return "bg-indigo-600";
      case "delivered":
        return "bg-green-600";
      default:
        return "bg-gray-400";
    }
  };

  return (
    <main className="min-h-screen bg-gray-50 py-10">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-xl shadow-lg">

        <h1 className="text-3xl font-bold mb-4 text-center">
          🚚 Track Your Order
        </h1>

        <p className="text-center mb-2">
          Order ID: #{order._id.slice(-6)}
        </p>

        <p className="text-center text-green-600 mb-6">
          Estimated Delivery:{" "}
          {new Date(order.estimatedDeliveryTime).toLocaleTimeString()}
        </p>

        {/* ================= PROGRESS BAR ================= */}
        <div className="relative flex justify-between items-center mb-10">

          {statusSteps.map((step, index) => (
            <div key={step} className="flex-1 text-center relative">

              {/* Circle */}
              <div
                className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center text-white
                ${
                  index <= currentStep
                    ? getStatusColor(order.status)
                    : "bg-gray-300"
                }`}
              >
                {index + 1}
              </div>

              <p className="mt-2 text-sm capitalize">
                {step.replaceAll("_", " ")}
              </p>

              {/* Line */}
              {index < statusSteps.length - 1 && (
                <div
                  className={`absolute top-4 left-full w-full h-1
                  ${
                    index < currentStep
                      ? getStatusColor(order.status)
                      : "bg-gray-300"
                  }`}
                />
              )}
            </div>
          ))}

        </div>

        {/* ================= ORDER ITEMS ================= */}
        <div className="space-y-2">
          {order.items.map((item) => (
            <div key={item._id} className="flex justify-between">
              <span>
                {item.menuItem?.name} × {item.quantity}
              </span>
              <span>
                ₹{item.menuItem?.price * item.quantity}
              </span>
            </div>
          ))}
        </div>

        <hr className="my-4" />

        {/* ================= BILL DETAILS ================= */}
        <div className="space-y-2">

          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>₹{order.subtotal}</span>
          </div>

          <div className="flex justify-between">
            <span>Delivery Fee</span>
            <span>₹{order.deliveryFee}</span>
          </div>

          {order.discount > 0 && (
            <div className="flex justify-between text-green-600 font-medium">
              <span>
                Discount ({order.couponCode})
              </span>
              <span>-₹{order.discount}</span>
            </div>
          )}

          <hr />

          <div className="flex justify-between font-bold text-lg">
            <span>Total Paid</span>
            <span>
              ₹{order.finalTotal || order.totalPrice}
            </span>
          </div>

        </div>

      </div>
    </main>
  );
}