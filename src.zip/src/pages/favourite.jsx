import React from "react";
import { FaHeart, FaShoppingCart } from "react-icons/fa";

export default function Favorites({ favorites, toggleFavorite, addToCart }) {

  if (!favorites || favorites.length === 0)
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <p className="text-gray-600 text-xl">
          You have no favorite items yet.
        </p>
      </div>
    );

  return (
    <main className="bg-gray-50 py-8 min-h-screen">
      <div className="container mx-auto px-6">
        <h1 className="text-3xl font-bold mb-6 text-center">
          Your Favorites
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {favorites.map((item) => (
            <article
              key={item._id}
              className="bg-white rounded-xl shadow-lg overflow-hidden flex flex-col"
            >
              <div className="w-full aspect-square overflow-hidden">
                <img
                  src={`http://localhost:5001${item.image}`}
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="p-4 flex flex-col flex-grow">
                <h3 className="text-lg font-semibold mb-2">{item.name}</h3>

                <div className="mt-auto flex items-center justify-between gap-2">
                  <button
                    onClick={() => toggleFavorite(item)}
                    className="p-2 rounded-lg bg-red-500 text-white"
                  >
                    <FaHeart />
                  </button>

                  <button
                    onClick={() => addToCart(item)}
                    className="px-4 py-2 bg-yellow-600 text-white rounded-lg flex items-center gap-2"
                  >
                    <FaShoppingCart /> Add
                  </button>

                  <span className="font-bold text-lg">
                    ₹{item.price}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}
