import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Home from "./pages/Home.jsx";
import Menu from "./pages/menu.jsx";
import About from "./pages/about.jsx";
import AdminDashboard from "./pages/admindashboard.jsx";
import AdminAnalytics from "./pages/AdminAnalytics";
import AdminCoupons from "./pages/admincoupons.jsx";
import Cart from "./pages/cart.jsx";
import Checkout from "./pages/checkout.jsx";
import Favorites from "./pages/favourite.jsx";
import Login from "./pages/login.jsx";
import Profile from "./pages/Profile.jsx";
import Register from "./pages/register.jsx";
import TrackOrder from "./pages/trackorder.jsx";
import OrderHistory from "./pages/orderhistory.jsx";
import OrderSuccess from "./pages/ordersuccess.jsx";
import PaymentSuccess from "./pages/payment-success.jsx";
import PaymentCancel from "./pages/payment-cancel";

import api from "./lib/apiClient";

function App() {

  const [user, setUser] = useState(() =>
    JSON.parse(localStorage.getItem("user")) || null
  );

  const [cartItems, setCartItems] = useState([]);
  const [favorites, setFavorites] = useState([]);

  const [notification, setNotification] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!user?.token) {
        setCartItems([]);
        setFavorites([]);
        return;
      }

      try {
        const favRes = await api.get("/favourites");
        setFavorites(
          favRes.data.map((item) => ({
            ...item.menuItem,
          }))
        );

        const cartRes = await api.get("/cart");
        setCartItems(
          cartRes.data.map((item) => ({
            ...item.menuItem,
            quantity: item.quantity,
          }))
        );
      } catch (err) {
        console.error("Error loading data:", err.response?.data || err.message);
      }
    };

    fetchData();
  }, [user]);

  // ===============================
  // SIMPLE MESSAGE FUNCTION
  // ===============================
  const showMessage = (message) => {
    setNotification(message);

    setTimeout(() => {
      setNotification(null);
    }, 3000);
  };

  // ===============================
  // ADD TO CART
  // ===============================
  const addToCart = async (item, decrease = false) => {
    if (!user) return alert("Please login first!");

    let updatedCart = [...cartItems];
    const index = updatedCart.findIndex((i) => i._id === item._id);

    try {
      if (index !== -1) {
        updatedCart[index].quantity += decrease ? -1 : 1;

        if (updatedCart[index].quantity <= 0) {
          updatedCart.splice(index, 1);
          await api.delete(`/cart/${item._id}`);
          showMessage(`${item.name} removed from cart 🗑️`);
        } else {
          await api.post("/cart", { menuItemId: item._id });
          if (!decrease)
            showMessage(`${item.name} added to cart 🛒`);
        }
      } else if (!decrease) {
        updatedCart.push({ ...item, quantity: 1 });
        await api.post("/cart", { menuItemId: item._id });
        showMessage(`${item.name} added to cart 🛒`);
      }

      setCartItems(updatedCart);
    } catch (err) {
      showMessage("Cart action failed ❌");
    }
  };

  // ===============================
  // REMOVE FROM CART
  // ===============================
  const removeFromCart = async (id) => {
    const item = cartItems.find((i) => i._id === id);

    try {
      await api.delete(`/cart/${id}`);
      setCartItems(cartItems.filter((i) => i._id !== id));
      showMessage(`${item?.name} removed from cart 🗑️`);
    } catch (err) {
      showMessage("Remove failed ❌");
    }
  };

  // ===============================
  // CLEAR CART
  // ===============================
  const clearCart = async () => {
    try {
      await api.delete("/cart/clear");

      setCartItems([]);

      localStorage.removeItem("cart");

      showMessage("Cart cleared 🛒");
    } catch (err) {
      showMessage("Clear failed ❌");
    }
  };
  // ===============================
  // TOGGLE FAVORITE
  // ===============================
  const toggleFavorite = async (item) => {
    if (!user) return alert("Please login first!");

    const exists = favorites.find((fav) => fav._id === item._id);

    try {
      if (exists) {
        await api.delete(`/favourites/${item._id}`);
        setFavorites(favorites.filter((fav) => fav._id !== item._id));
        showMessage(`${item.name} removed from favorites 💔`);
      } else {
        await api.post("/favourites", { menuItemId: item._id });
        setFavorites([...favorites, item]);
        showMessage(`${item.name} added to favorites ❤️`);
      }
    } catch (err) {
      showMessage("Favorite action failed ❌");
    }
  };

  return (
    <>
      <Navbar
        cartItems={cartItems}
        favorites={favorites}
        user={user}
        setUser={setUser}
      />

      {/* 🔥 SIMPLE NOTIFICATION UI */}
      {notification && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 bg-black text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-all duration-300">
          {notification}
        </div>
      )}

      <Routes>
        <Route path="/" element={<Home />} />

        <Route
          path="/menu"
          element={
            <Menu
              addToCart={addToCart}
              toggleFavorite={toggleFavorite}
              favorites={favorites}
              cartItems={cartItems}
            />
          }
        />

        <Route
          path="/favorites"
          element={
            user ? (
              <Favorites
                favorites={favorites}
                toggleFavorite={toggleFavorite}
                addToCart={addToCart}
              />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        <Route
          path="/cart"
          element={
            user ? (
              <Cart
                cartItems={cartItems}
                removeFromCart={removeFromCart}
                clearCart={clearCart}
                addToCart={addToCart}
              />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/checkout"
          element={
            user ? (
              <Checkout
                cartItems={cartItems}
                clearCart={clearCart}
              />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
        <Route
          path="/orders"
          element={
            <OrderHistory
              addToCart={addToCart}
            />
          }
        />

        <Route path="/about" element={<About />} />
        <Route path="/login" element={<Login setUser={setUser} />} />
        <Route path="/register" element={<Register setUser={setUser} />} />
        <Route
          path="/order-success/:id"
          element={<OrderSuccess setCartItems={setCartItems} />}
        />
        <Route
          path="/track-order/:id"
          element={
            user ? <TrackOrder /> : <Navigate to="/login" />
          }
        />
        <Route
          path="/admin"
          element={
            user?.role === "admin" ? (
              <AdminDashboard />
            ) : (
              <Navigate to="/" />
            )
          }
        />

        <Route path="/admin/analytics" element={<AdminAnalytics />} />
        <Route path="/admin/coupons" element={<AdminCoupons />} />
        <Route path="/payment-success" element={<PaymentSuccess />} />
        <Route path="/payment-cancel" element={<PaymentCancel />} />

        <Route
          path="/profile"
          element={
            user ? (
              <Profile user={user} setUser={setUser} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        <Route
          path="/orders"
          element={
            user ? (
              <OrderHistory user={user} />
            ) : (
              <Navigate to="/login" />
            )
          }
        />
      </Routes>

    </>
  );
}

export default App;
